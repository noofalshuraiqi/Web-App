package com.alshuraiqi.controller;

import com.alshuraiqi.model.Order;
import com.alshuraiqi.model.User;
import com.alshuraiqi.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @GetMapping
    public String listOrders(Long id, Model model) {
        List<Order> orders = orderService.findByUserId(id);
        model.addAttribute("orders", orders);
        return "orders";
    }

    @PostMapping
    public String saveOrder(@ModelAttribute Order order, @AuthenticationPrincipal UserDetails userDetails) {
        order.setUser((User) userDetails);
        orderService.save(order);
        return "redirect:/orders";
    }
}
