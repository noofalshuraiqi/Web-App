package com.alshuraiqi.controller;

import com.alshuraiqi.model.Complaint;
import com.alshuraiqi.model.User;
import com.alshuraiqi.service.ComplaintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/complaints")
public class ComplaintController {

    @Autowired
    private ComplaintService complaintService;

    @GetMapping
    public String listComplaints(Long id, Model model) {
        List<Complaint> complaints = complaintService.findByUserId(id);
        model.addAttribute("complaints", complaints);
        return "complaints";
    }

    @PostMapping
    public String saveComplaint(@ModelAttribute Complaint complaint, @AuthenticationPrincipal UserDetails userDetails) {
        complaint.setUser((User) userDetails);
        complaintService.save(complaint);
        return "redirect:/complaints";
    }
}
