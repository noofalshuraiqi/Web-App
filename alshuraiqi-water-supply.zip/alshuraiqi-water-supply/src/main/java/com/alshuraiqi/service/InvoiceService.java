package com.alshuraiqi.service;

import com.alshuraiqi.model.Invoice;
import com.alshuraiqi.repository.InvoiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InvoiceService {

    @Autowired
    private InvoiceRepository invoiceRepository;

    public Invoice findByUserId(Long userId) {
        return (Invoice) invoiceRepository.findByUserId(userId);
    }

    public Invoice save(Invoice invoice) {
        return invoiceRepository.save(invoice);
    }
}
