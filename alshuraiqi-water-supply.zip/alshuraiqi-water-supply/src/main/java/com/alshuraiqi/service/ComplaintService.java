package com.alshuraiqi.service;

import com.alshuraiqi.model.Complaint;
import com.alshuraiqi.repository.ComplaintRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ComplaintService {

    @Autowired
    private ComplaintRepository complaintRepository;

    public List<Complaint> findByUserId(Long userId) {
        return complaintRepository.findByUserId(userId);
    }

    public Complaint save(Complaint complaint) {
        return complaintRepository.save(complaint);
    }
}
