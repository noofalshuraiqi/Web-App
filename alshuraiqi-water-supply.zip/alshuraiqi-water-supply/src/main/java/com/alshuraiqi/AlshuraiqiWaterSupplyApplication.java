package com.alshuraiqi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlshuraiqiWaterSupplyApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlshuraiqiWaterSupplyApplication.class, args);
	}

}
